const { getProductsList } = require('./hadlers/getProductsList');
const { getProductById } = require('./hadlers/getProductById');

module.exports = {
  getProductsList,
  getProductById
};
